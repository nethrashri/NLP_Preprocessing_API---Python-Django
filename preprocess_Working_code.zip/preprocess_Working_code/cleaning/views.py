# result = Stemming('good afternooooon hassssss buddyy gooooods cannnot trainingssss digitaalll hte')


from django.shortcuts import render

from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.core.mail import BadHeaderError, send_mail
from django.conf import settings
from datetime import datetime,timedelta
from django.http import JsonResponse,HttpResponse
import json


# Create your views here.
@csrf_exempt
def clean(request):
    if request.method == 'POST':
        print(request.body)
        JS = json.loads(request.body)
        input = JS["usertext"] 
        print(input, "print the input from the bot")
        result = Stemming(input)
        print(result)
        
        return JsonResponse({"text":result})



import pandas as pd
import re
import string
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from nltk.stem import WordNetLemmatizer
from nltk.corpus import treebank_chunk
from autocorrect import Speller
from nltk.stem import SnowballStemmer
from textblob import TextBlob


stop_words=set(stopwords.words('english'))
spell = Speller(lang='en')
# ps = PorterStemmer()
sno = SnowballStemmer("english",ignore_stopwords=True)


def Stemming(text):
    word_tokens = word_tokenize(text) #extracting tokens from sentences
    snstems=[]
    for w in word_tokens:
        temp = ''
        for i in w:
            if i not in temp or temp.count(i)<2: 
                temp += i
        y= spell(sno.stem(temp))
        if y=='diadem':
            y='diageo'
        snstems.append(y)
    snstems= " ".join(snstems)
    return snstems 



def pre_processing(text):
        utter= text.lower() #converting to lower case
        utter= re.sub(r'\d+', '', utter) #removing numbers
        utter= re.sub('[%s]' % re.escape(string.punctuation),'', utter) #removing punctuation marks
        utter= re.sub(r"\b[a-zA-Z]\b", "", utter)#removing single characters
        utter= re.sub(' +', ' ', utter) #removing multiple spaces
        utter = TextBlob(utter)
        x=utter.words.singularize();
        y=[]
        for wlist in x:
             y.append(wlist)
        utter=" ".join(y)
        utter= utter.strip()
        utter= Stemming(utter)
        return utter


pre_processing('good afternooooon hassssss buddyy gooooods cannnot trainingssss digitaalll hte')




